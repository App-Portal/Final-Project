package com.example.admin;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@CrossOrigin(value="http://localhost:4200")
@Controller    
@RequestMapping(value= {"/admin"}) // This means URL's start with /demo (after Application path)
public class Skillcontroller {
	@Autowired 
	private Skillsrepository Srep;
	
	
	@GetMapping(value= {"/addentry/{technology}"},produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String addNew (@Valid @PathVariable String technology) {
		Skill s = new Skill();
		s.setSkillname(technology);
		Srep.save(s);
		return "Saved";
	}

	@GetMapping(value= "/remove/{tech}",produces = MediaType.APPLICATION_JSON_VALUE) 
	public @ResponseBody String delete (@Valid @PathVariable String tech) {
		Iterable<Skill> all = Srep.findAll();
		for(Skill skill:all) {
			if(skill.getSkillname().equals(tech)) {
				Srep.deleteById(skill.getSkillid());
			}
		}
		return "Skill Removed";
	}
	
	@GetMapping(value = "/allskills", produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Iterable<Skill> skills() {
		return Srep.findAll();
	}
	
	//	@RequestMapping(value= {"/"}) 
//	public @ResponseBody String addNewUser () {
////		Map<Integer,String> person = new HashMap<Integer,String>();
//		
//		Rrep.save(new Role(1,"Admin"));
//		Rrep.save(new Role(2,"Mentor"));
//		Rrep.save(new Role(3,"User"));
//
//		return "Saved";
//	}
	
//	@GetMapping(value= {"/all"})
//	public @ResponseBody Iterable<Authorization> getAllUsers() {
//		return Arep.findAll();
//	}

}
