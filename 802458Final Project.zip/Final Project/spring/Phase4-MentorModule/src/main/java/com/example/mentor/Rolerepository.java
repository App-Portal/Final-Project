package com.example.mentor;

import org.springframework.data.repository.CrudRepository;


public interface Rolerepository extends CrudRepository<Role, Integer> {

}
