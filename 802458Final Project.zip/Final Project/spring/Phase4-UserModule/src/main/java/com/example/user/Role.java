package com.example.user;

import javax.persistence.Entity;
import javax.persistence.Id;

	@Entity
	public class Role {
			
		 	@Id
		 	private Integer roleid;
		 	
		    private String rolename;

		    public Role() {
		    	
		    }
		    
			public Role(Integer roleid, String rolename) {
				super();
				this.roleid =roleid;
				this.rolename = rolename;
			}

			public Integer getRoleid() {
				return roleid;
			}

			public void setRoleid(Integer roleid) {
				this.roleid = roleid;
			}

			public String getRolename() {
				return rolename;
			}

			public void setRolename(String rolename) {
				this.rolename = rolename;
			}
}
