import { Component, OnInit } from '@angular/core';
import { CompletedTrainingService } from '../completed-training.service';

@Component({
  selector: 'app-admin-edit-tech',
  templateUrl: './admin-edit-tech.component.html',
  styleUrls: ['./admin-edit-tech.component.css']
})
export class AdminEditTechComponent implements OnInit {
    value:string;  // value=adder
    minus:string;
    private technology: string[];
    constructor(private bb:CompletedTrainingService) { }
  
    ngOnInit() {
      this.showtech();
    }
  
    method(){   //add method
      if(this.value != ""){
      this.bb.addtech(this.value).subscribe(data=>console.log(data),error=>console.log(error));
      this.value = "";
    }
    }
    deletemethod(){  //to remove data
      if(this.minus != ""){
        this.bb.removetechnology(this.minus).subscribe(data=>console.log(data),error=>console.log(error));
        this.minus="";
      }
    }
    showtech(){
      this.bb.displaytechnology().subscribe(value=>this.technology=value as string[]);
    }
  }
