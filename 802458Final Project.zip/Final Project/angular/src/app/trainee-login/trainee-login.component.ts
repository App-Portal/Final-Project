import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { CompletedTrainingService } from '../completed-training.service';


export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid: Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

@Component({
  selector: 'app-trainee-login',
  templateUrl: './trainee-login.component.html',
  styleUrls: ['./trainee-login.component.css']
})
export class TraineeLoginComponent implements OnInit {

  email:string;
  pass:string;
  invalidmentor: string;

  //auth:Authorization = new Authorization();
  private auth2:Authorization = new Authorization();
  constructor(private router: Router,private service:CompletedTrainingService) { }



  ngOnInit() {
  }
  // submit(){
  //   if(this.email==null){
  //     alert("enter valid mail address");
  //   }
    
  //   else if(this.pass==null){
  //     alert("enter password");
  //   }
  //   else{
  //     this.userlogin.navigate(['/trainee']);
  //   }

  // }

  mentorlogin(){
    if((this.email != null)&&(this.pass != null)){
      this.service.getloginmentor(this.email).subscribe(value=>this.auth2=value as Authorization);
      // console.log(this.auth2.roleid.roleid);
      this.myfunc();
    }
      else{
        this.invalidmentor = "Enter valid details!!!";
      }
  }
  myfunc(){
    console.log(this.auth2.password);

    if((this.pass == this.auth2.password)&&(this.auth2.roleid.roleid == 3)){
      this.invalidmentor =  "";
      this.router.navigate(['/currentTraining']);
    }
    else{
      this.invalidmentor = "Not a registered mentor!!!";
    }
  }
 
  }

