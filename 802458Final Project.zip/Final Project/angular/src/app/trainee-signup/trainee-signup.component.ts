import { Component, OnInit } from '@angular/core';
import { CompletedTrainingService } from '../completed-training.service';
import { Router } from '@angular/router';

export class User{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

@Component({
  selector: 'app-trainee-signup',
  templateUrl: './trainee-signup.component.html',
  styleUrls: ['./trainee-signup.component.css']
})
export class TraineeSignupComponent implements OnInit {

  // uname:string;
  // upass:string;
  val:string;
  
  username:string;
  mail:string;
  password:string;
  
  invaliduser:string;
  

  user:User=new User();
  role:Role=new Role();

  constructor(private router: Router,private service:CompletedTrainingService) { }


  ngOnInit() {
  }

  // ulogin(){
  //   if((this.uname==null)||(this.upass==null)){
  //     this.invaliduser = "Enter valid details!!!";
  //   }
  //   else {
  //     this.invaliduser = "";
  //     this.router.navigate(['/traineeLogin']);
  // }}
  loginpage() {
    this.router.navigate(['/traineeLogin']);
  }
  onsign(){
    if(this.username!=null && this.mail!=null && this.password!=null){
    this.user.username=this.username;
    this.user.mail=this.mail;
    this.user.password=this.password;
    this.role.roleid=3;
    this.role.rolename="user";
    this.user.roleid=this.role;
    this.service.saveUser(this.user).subscribe();

    this.username=null;
    this.mail=null;
    this.password=null;
    this.val="";
     this.loginpage();
    }
    else{
      this.val = "Enter valid details";
    }
    
  }
 
 
}
