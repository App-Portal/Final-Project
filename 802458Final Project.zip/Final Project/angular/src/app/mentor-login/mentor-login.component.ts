import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { CompletedTrainingService } from '../completed-training.service';


export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {

  email:string;
  pass:string;
  invalidmentor: string;

  //auth:Authorization = new Authorization();
  private auth2:Authorization = new Authorization();
  constructor(private router: Router,private service:CompletedTrainingService) { }

  ngOnInit() {
  }
  // submit(){
  //   if(this.email==null){
  //     alert("enter valid mail address");
  //   }
    
  //   else if(this.pass==null){
  //     alert("enter password");
  //   }
  //   else{
  //     this.userlogin.navigate(['/mentor']);
  //   }

  // }
  mentorlogin(){
    if((this.email != null)&&(this.pass != null)){
      this.service.getloginmentor(this.email).subscribe(value=>this.auth2=value as Authorization);
     console.log(this.auth2.password);
     //console.log(this.auth2.roleid.roleid);
      if((this.pass == this.auth2.password)&&(this.auth2.roleid.roleid == 2)){
        this.invalidmentor =  "";
        this.router.navigate(['/mentor']);
      }
      else if((this.pass == this.auth2.password)&&(this.auth2.roleid.roleid == 3)){
        this.invalidmentor =  "";
        this.router.navigate(['/trainee']);
      }
      else if((this.pass == this.auth2.password)&&(this.auth2.roleid.roleid == 1)){
        this.invalidmentor =  "";
        this.router.navigate(['/admineditskills']);
      }
      else{
        this.invalidmentor = "Not a registered mentor!!!";
      }
    }
    else{
      this.invalidmentor = "Enter valid details!!!";
    }
  }
}
