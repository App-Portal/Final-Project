export class Usercompletedtraining{
    trainername:string;
    course:string;
    completion:Int16Array;
}