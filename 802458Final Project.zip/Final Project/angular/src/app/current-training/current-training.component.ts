import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CompletedTrainingService } from '../completed-training.service';

@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  constructor(private user: CompletedTrainingService) { }
//   constructor(private httpservice : HttpClient) { }
//   technology : string[];
//   ptr : number = 0;
//   ngOnInit() {

//     this.httpservice.get('../../assets/currenttrainingstrainee.json').subscribe(

//       data=>{
//         this.technology = data as string[];
//       },
//       (err : HttpErrorResponse) => {
//         console.log(err.message);
//       }
//     )
//     }
// }
private mcurrent:string[];

ngOnInit() {
  this.test1();
}

test1() {
  this.user.getcurrent().subscribe(value=>this.mcurrent=value as string[]);
}
}