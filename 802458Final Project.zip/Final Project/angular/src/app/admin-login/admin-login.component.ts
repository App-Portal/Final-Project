import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  email:string;
  pass:string;

  constructor(private userlogin: Router) { }

  ngOnInit() {
  }
  submit(){
    if(this.email==null){
      alert("enter valid mail address");
    }
    
    else if(this.pass==null){
      alert("enter password");
    }
    else{
      this.userlogin.navigate(['/admin']);
    }

  }

}
